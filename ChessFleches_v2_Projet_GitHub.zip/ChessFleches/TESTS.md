# Vérifications de Chess Flèches 0.2

1. Compilation de **toutes les sources Java** via javac et des *stubs* Android
   (contrôle de syntaxe seulement, pas de compilation APK sur Android SDK).
2. Moteur d'échecs : **20 coups légaux** au départ ; perft profondeur 3 =
   **8 902** positions, et conversion FEN aller-retour validée.
3. Le moteur donne au départ des coups **distincts** pour les 5 critères lors
   du test de bureau (ex. Fou : d2d4 ; Défensif : b1c3 ; Attaque : e2e4 ;
   Humain : g1f3 ; Pièges : f2f4), **sans garantie de force particulière**.
4. Sur la capture de Chess Universe fournie (709 × 1536), le détecteur
   situe le damier à **x=0, y=414, taille 709**.
5. Le scan reconstruit la position déjà entamée, avec les Noirs au trait :
   `2kr1r2/1p1qbpp1/p1n1bn1p/4p3/2p1P3/4BN1P/PPPNKPP1/R2QRB2 b - - 0 1`.
6. Sur la capture inchangée, aucun faux déplacement n'est détecté.
7. Sur une **image simulée** en déplaçant la dame de d7 à d5, le détecteur
   trouve `d7d5` comme déplacement probable.

**Non testé** : comportement sur un vrai téléphone après mise à jour,
reconnaissance de captures indépendantes, thèmes autres que celui fourni,
robustesse sur une longue partie, compilation APK réelle dans cette session.
