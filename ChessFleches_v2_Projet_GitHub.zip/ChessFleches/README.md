# Chess Flèches 0.2 — application Android expérimentale

Cette version corrige le prototype qui affichait **toujours d7d5** et qui demandait
la position initiale. Elle tente de **reconnaître une partie Chess Universe déjà
commencée**, affiche de **1 à 5 flèches** et permet de choisir les styles.

## Nouveautés

- **Scan de position déjà commencée** : identifie les pièces depuis une capture
  de Chess Universe (thème brun/crème visible sur la capture fournie), sans
  exiger les 32 pièces initiales. Le scan attend deux images cohérentes avant
  de lancer l'analyse. Si la reconnaissance est incertaine, les flèches
  restent cachées au lieu d'afficher un coup inventé.
- **Suivi automatique** : surveille les captures suivantes et attend deux
  détections stables du même coup *légal* avant de mettre à jour la position.
  Bouton ↻ pour resynchroniser à n'importe quel moment.
- **Réglages** : appui sur ⚙ dans la bulle flottante, puis définir la couleur,
  le joueur au trait au premier scan, la force d'analyse, le nombre de flèches
  (1–5) et les styles à afficher.
- **Couleur = style, pas rang** :
  - Fou : violet (#E879F9), recherche de coups tranchants et sacrifices calculés ;
  - Défensif : bleu (#55B9FF), coups solides ;
  - Attaque : rouge (#FF646C), pression et échecs ;
  - Humain : turquoise (#25D5BF), développement naturel ;
  - Pièges : orange (#FFB443), menaces tactiques.
- Un mode ou plusieurs peuvent être cochés. Si un seul est coché, plusieurs
  flèches peuvent partager sa couleur. Si plusieurs sont sélectionnés, le
  moteur cherche des propositions distinctes pour leurs critères.
- **FEN facultatif** : si le scan ne reconnaît pas le thème, un code de
  position peut être renseigné dans les paramètres.
- La nouvelle version conserve le même identifiant Android (versionCode 2).
  **Attention :** une compilation Google Colab indépendante utilise souvent une
  signature de test différente. **Désinstalle l'ancienne application** sur ton
  Samsung avant d'installer la v0.2 si Android refuse la mise à jour.

## Comment lancer sur ton Samsung

1. Si l'ancienne application est installée, désinstalle-la d'abord pour éviter
   un refus lié à la signature Android de test. Puis installe l'APK
   `ChessFleches_v2.apk` construit avec le carnet Google Colab.
2. Ouvre Chess Universe, y compris une partie ou un puzzle déjà en cours.
3. Dans Chess Flèches, coche les styles, le nombre de flèches et ta couleur.
4. Pour une position déjà commencée, choisis **Moi** si c'est toi qui dois
   jouer le prochain coup ; sinon **L'adversaire**.
5. Appuie **DÉMARRER LA CAPTURE** et autorise le partage de l'écran.
6. Retourne à Chess Universe, sans déplacer la bulle au-dessus des pièces.
7. La bulle affiche le coup principal et les flèches sur le plateau ; appuie
   sur ⚙ pour changer les critères, ou ↻ si la position change sans suivi.
8. Une fois les réglages changés, appuie sur **ENREGISTRER ET RETOURNER AU JEU**.

## Limitations transparentes

- **Reconnaissance visuelle expérimentale**, entraînée ici sur **une seule
  capture de Chess Universe fournie par l'utilisateur**. Le thème, les
  surbrillances, les animations et une autre résolution de plateau peuvent
  induire des erreurs. Les tests ne garantissent pas un fonctionnement fiable
  sur toutes les parties ; une position mal reconnue peut être plausible.
- Le détecteur localise surtout les plateaux qui **occupent toute la largeur**
  de l'écran et conservent les couleurs du thème fourni.
- Dans une position prise en cours de route, les droits au roque et une
  éventuelle prise en passant **ne peuvent pas être connus depuis une image**.
  Le scan désactive le roque par prudence ; fournir une FEN si nécessaire.
- Le moteur est un petit moteur Java autonome (profondeur ≤5), **pas Stockfish**.
  Le mode **Fou** reprend une intention de jeu (gambits, sacrifices, activité)
  mais ne reproduit ni le code ni la force du mode d'un éditeur tiers.
- Aucun fichier APK n'a été compilé **dans cet environnement** ; le carnet
  Colab inclut les sources et les commandes de compilation. Le code Android
  a été vérifié avec des stubs Java mais **pas sur un appareil réel** dans cette
  session. Les captures restent sur le téléphone, sans transmission serveur.
- À utiliser pour s'entraîner, les puzzles ou contre l'ordinateur. Une
  assistance lors de parties compétitives en ligne peut enfreindre leurs règles.

## Construire l'APK

Sur Google Colab : ouvre le fichier `Compiler_ChessFleches_v2_Colab.ipynb`,
appuie une fois sur ▶, autorise la connexion et récupère `ChessFleches_v2.apk`.
Cela nécessite Internet et une session Colab active pendant toute la compilation.

Ou dans Android Studio : ouvrir `ChessFleches`, synchroniser Gradle, puis
**Build > Build APK(s)**. APK : `app/build/outputs/apk/debug/app-debug.apk`.

## Organisation

- `MainActivity.java` : paramètres (styles, flèches, force, couleur, FEN).
- `CaptureService.java` : capture + stabilisation des coups + réglages en direct.
- `BoardVision.java` : détection du plateau et reconnaissance en milieu de partie.
- `assets/chess_universe_reference.bin` : silhouettes de la capture fournie.
- `StyleMode.java` : mode et couleur associés.
- `TacticalEngine.java` : analyse et critères des styles.
- `Chess.java` : règles légales et parsing de FEN.
- `OverlayUI.java` : bulle flottante, bouton ⚙ et flèches de couleur.
