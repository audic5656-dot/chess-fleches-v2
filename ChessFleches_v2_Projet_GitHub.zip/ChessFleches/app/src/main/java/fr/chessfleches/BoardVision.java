package fr.chessfleches;

import android.content.Context;
import android.graphics.Bitmap;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.util.ArrayList;
import java.util.List;

/** Chess Universe : scan d'une position déjà commencée, puis suivi de coups légaux.
 *  Reconnaissance expérimentale par silhouettes extraites d'une capture fournie.
 *  Un thème différent peut nécessiter de nouvelles références visuelles. */
public class BoardVision {
  public static class Box { public final int x,y,size; public Box(int a,int b,int c){x=a;y=b;size=c;} }
  private static final char[] TYPES=".PNBRQKpnbrqk".toCharArray();
  private static final int F=16, FEATURE_LENGTH=F*F*3;
  private static final double[][] BG={{253,238,205},{200,170,140}};
  @SuppressWarnings("unchecked")
  private final List<double[]>[] library=new List[TYPES.length];
  @SuppressWarnings("unchecked")
  private final List<double[]>[] learned=new List[TYPES.length];
  private Box board;
  private boolean ready=false;
  public BoardVision(Context ctx){
    for(int i=0;i<TYPES.length;i++){library[i]=new ArrayList<>();learned[i]=new ArrayList<>();}
    try(DataInputStream in=new DataInputStream(new BufferedInputStream(ctx.getAssets().open("chess_universe_reference.bin")))){
      if(in.readInt()!=0x43464832)throw new IllegalStateException("Modèles invalides");
      int size=in.readInt();
      for(int i=0;i<size;i++){
        char piece=(char)in.readUnsignedShort();double[] f=new double[FEATURE_LENGTH];
        for(int j=0;j<f.length;j++)f[j]=in.readUnsignedByte()/255.0;
        library[typeIndex(piece)].add(f);
      }
    }catch(Exception error){android.util.Log.e("ChessFleches","Impossible de charger le thème",error);}
  }
  private static int typeIndex(char p){for(int i=0;i<TYPES.length;i++)if(TYPES[i]==p)return i;return 0;}
  public void reset(){board=null;ready=false;for(List<double[]> v:learned)v.clear();}
  public boolean calibrated(){return ready;}
  public Box board(){return board;}
  public static int internal(int row,int col,boolean whiteBottom){return whiteBottom?row*8+col:(7-row)*8+7-col;}
  private static int pixel(Bitmap bitmap,int x,int y){return bitmap.getPixel(Math.max(0,Math.min(bitmap.getWidth()-1,x)),Math.max(0,Math.min(bitmap.getHeight()-1,y)));}
  private static int channel(int color,int shift){return (color>>shift)&255;}
  private static double diff(int a,int b){return (Math.abs(channel(a,16)-channel(b,16))+Math.abs(channel(a,8)-channel(b,8))+Math.abs(channel(a,0)-channel(b,0)))/3.0;}

  /** Bord supérieur du damier par les neuf séparations horizontales de 8 lignes.
   *  Contrairement à l'ancienne recherche, ne décale pas l'origine d'une rangée. */
  private Box fullWidth(Bitmap image){
    int w=image.getWidth(),h=image.getHeight();
    if(w<280||h<w+40)return null;
    int size=w, lo=Math.max(8,(int)(h*.07)),hi=h-size-8;
    if(lo>=hi)return null;
    double best=-1;int bestY=-1;
    int[] xs=new int[8];for(int c=0;c<8;c++)xs[c]=(int)((c+.14)*size/8);
    for(int y=lo;y<hi;y+=2){
      double score=0;
      for(int r=0;r<=8;r++){
        int yy=y+(int)(r*size/8.0);
        for(int c=0;c<8;c++)score+=diff(pixel(image,xs[c],yy-2),pixel(image,xs[c],yy+2));
      }
      if(score>best){best=score;bestY=y;}
    }
    // Certaines apps affichent un damier bord à bord ; minimum de contraste.
    return best>1300?new Box(0,bestY,size):null;
  }
  public Box detectOnScreen(Bitmap image){
    int w=image.getWidth(),h=image.getHeight();int scale=Math.max(1,(int)Math.ceil(Math.max(w,h)/950.0));
    Bitmap small=scale==1?image:Bitmap.createScaledBitmap(image,Math.max(1,w/scale),Math.max(1,h/scale),false);
    Box value=fullWidth(small);
    if(small!=image)small.recycle();
    if(value==null)return null;
    return new Box(0,(int)Math.round(value.y*(h/(double)(h/scale))),w);
  }
  private double[] feature(Bitmap image,Box b,int r,int c){
    double[] f=new double[FEATURE_LENGTH];double[] bg=BG[(r+c)&1];double sq=b.size/8.0;
    int n=0;
    for(int yy=0;yy<F;yy++)for(int xx=0;xx<F;xx++){
      double u=.12+.80*(xx+.5)/F,v=.12+.80*(yy+.5)/F;
      int x=(int)Math.round(b.x+(c+u)*sq),y=(int)Math.round(b.y+(r+v)*sq);
      double R=0,G=0,B=0;
      for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){
        int color=pixel(image,x+dx,y+dy);R+=channel(color,16);G+=channel(color,8);B+=channel(color,0);
      }
      R/=9;G/=9;B/=9;
      double d=Math.sqrt(((R-bg[0])*(R-bg[0])+(G-bg[1])*(G-bg[1])+(B-bg[2])*(B-bg[2]))/3.0);
      double mean=(R+G+B)/3.0,base=(bg[0]+bg[1]+bg[2])/3.0;
      f[n++]=clip((d-25)/75);f[n++]=clip((base-mean-12)/100);f[n++]=clip((mean-base-8)/65);
    }
    return f;
  }
  private static double clip(double v){return Math.max(0,Math.min(1,v));}
  private double[] costs(double[] f){
    double[] out=new double[TYPES.length];double e=0;
    for(int i=0;i<f.length;i+=3)e+=f[i]*f[i];
    out[0]=(e/(F*F))*18; // L'absence de silhouette privilégie une case vide.
    for(int kind=1;kind<TYPES.length;kind++){
      double min=25;
      for(double[] t:library[kind])min=Math.min(min,distance(f,t));
      for(double[] t:learned[kind])min=Math.min(min,distance(f,t));
      out[kind]=min*18;
    }
    return out;
  }
  private static double distance(double[] a,double[] b){double total=0;for(int i=0;i<a.length;i++){double v=a[i]-b[i];total+=v*v;}return total/a.length;}
  public double[][] readCosts(Bitmap image){
    if(board==null)return null;
    double[][] out=new double[64][TYPES.length];
    for(int r=0;r<8;r++)for(int c=0;c<8;c++)out[r*8+c]=costs(feature(image,board,r,c));
    return out;
  }
  private static double gameCost(double[][] costs,Chess.Board position,boolean whiteBottom){
    double sum=0;
    for(int r=0;r<8;r++)for(int c=0;c<8;c++)sum+=costs[r*8+c][typeIndex(position.b[internal(r,c,whiteBottom)])];
    return sum;
  }
  /** Réconstruit les pièces depuis l'image, sans exiger la position initiale. */
  public Chess.Board scanPosition(Bitmap image,Box rect,boolean whiteBottom,boolean whiteToMove){
    if(rect==null)return null;
    board=rect;
    double[][] scores=readCosts(image);
    Chess.Board found=new Chess.Board();found.whiteTurn=whiteToMove;
    // Droits au roque inconnus pour une partie déjà entamée : ne jamais les inventer.
    found.rights=0;found.ep=-1;
    int unsure=0;
    for(int r=0;r<8;r++)for(int c=0;c<8;c++){
      double[] s=scores[r*8+c];int best=0;double v=s[0];double second=100;
      for(int k=1;k<s.length;k++){
        if(s[k]<v){second=v;v=s[k];best=k;}else second=Math.min(second,s[k]);
      }
      if(best>0&&v>2.70){best=0;unsure++;}
      if(best>0&&second-v<.08)unsure++;
      found.b[internal(r,c,whiteBottom)]=TYPES[best];
    }
    return unsure<=9&&Chess.plausible(found)?found:null;
  }
  /** Apprentissage de ce qui est reconnu, quelle que soit la position des pièces. */
  public void calibrate(Bitmap image,Box rect,Chess.Board game,boolean whiteBottom){
    board=rect;ready=true;
    for(List<double[]> l:learned)l.clear();
    for(int r=0;r<8;r++)for(int c=0;c<8;c++){
      char p=game.b[internal(r,c,whiteBottom)];int i=typeIndex(p);
      if(i>0)learned[i].add(feature(image,rect,r,c));
    }
  }
  public Chess.Move detectMove(Bitmap image,Chess.Board game,boolean whiteBottom){
    double[][] values=readCosts(image);if(values==null)return null;
    double base=gameCost(values,game,whiteBottom),min=Double.MAX_VALUE,second=Double.MAX_VALUE;
    Chess.Move best=null;
    for(Chess.Move m:Chess.legal(game)){
      double v=gameCost(values,Chess.move(game,m),whiteBottom);
      if(v<min){second=min;min=v;best=m;}else if(v<second)second=v;
    }
    return best!=null&&base-min>.45&&second-min>.12?best:null;
  }
}
