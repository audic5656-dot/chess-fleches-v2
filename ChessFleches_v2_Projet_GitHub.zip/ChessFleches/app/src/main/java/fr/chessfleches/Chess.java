package fr.chessfleches;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Moteur et règles autonomes. Indices : a8=0, h1=63. */
public final class Chess {
  private Chess() {}
  public static final String START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
  public static final int CASTLE_WK=1, CASTLE_WQ=2, CASTLE_BK=4, CASTLE_BQ=8;
  public static int row(int x){return x/8;} public static int col(int x){return x%8;}
  public static boolean white(char p){return p>='A'&&p<='Z';}
  public static boolean black(char p){return p>='a'&&p<='z';}
  public static boolean pieceFor(char p,boolean w){return p!='.' && (w?white(p):black(p));}
  public static boolean opp(char a,char b){return a!='.'&&b!='.'&&white(a)!=white(b);}
  public static String sq(int index){return "abcdefgh".charAt(col(index))+Integer.toString(8-row(index));}
  public static String uci(Move m){return sq(m.from)+sq(m.to)+(m.promotion!='.'?Character.toLowerCase(m.promotion):"");}

  public static class Move {
    public final int from,to; public final char promotion; public final boolean ep,castle;
    public Move(int a,int b){this(a,b,'.',false,false);}
    public Move(int a,int b,char p,boolean en,boolean cast){from=a;to=b;promotion=p;ep=en;castle=cast;}
    @Override public String toString(){return uci(this);}
  }
  public static class Board {
    public char[] b=new char[64]; public boolean whiteTurn=true; public int rights=15; public int ep=-1, halfmove=0, fullmove=1;
    public Board(){ for(int i=0;i<64;i++)b[i]='.'; }
    public Board copy(){Board x=new Board();x.b=b.clone();x.whiteTurn=whiteTurn;x.rights=rights;x.ep=ep;x.halfmove=halfmove;x.fullmove=fullmove;return x;}
    public String fen(){StringBuilder f=new StringBuilder();for(int r=0;r<8;r++){int empty=0;for(int c=0;c<8;c++){char p=b[r*8+c];if(p=='.')empty++;else{if(empty>0){f.append(empty);empty=0;}f.append(p);}}if(empty>0)f.append(empty);if(r<7)f.append('/');}f.append(whiteTurn?" w ":" b ");if(rights==0)f.append('-');else{if((rights&1)!=0)f.append('K');if((rights&2)!=0)f.append('Q');if((rights&4)!=0)f.append('k');if((rights&8)!=0)f.append('q');}f.append(' ').append(ep<0?"-":sq(ep)).append(' ').append(halfmove).append(' ').append(fullmove);return f.toString();}
  }
  public static Board fromFen(String fen){
    if(fen==null)throw new IllegalArgumentException("FEN vide");
    String[] f=fen.trim().split("\\s+");
    if(f.length<2)throw new IllegalArgumentException("FEN incomplète");
    Board b=new Board();String[] ranks=f[0].split("/");
    if(ranks.length!=8)throw new IllegalArgumentException("Il faut 8 rangées");
    int pos=0;
    for(String rank:ranks){int cells=0;for(char ch:rank.toCharArray()){
      if(ch>='1'&&ch<='8'){for(int n=0;n<ch-'0';n++){b.b[pos++]='.';cells++;}}
      else if("PNBRQKpnbrqk".indexOf(ch)>=0){b.b[pos++]=ch;cells++;}
      else throw new IllegalArgumentException("Pièce inconnue");
      if(cells>8)throw new IllegalArgumentException("Rangée trop longue");
    }if(cells!=8)throw new IllegalArgumentException("Rangée incomplète");}
    b.whiteTurn=f[1].equals("w");if(!f[1].equals("w")&&!f[1].equals("b"))throw new IllegalArgumentException("Tour invalide");
    b.rights=0;String rights=f.length>2?f[2]:"-";
    if(rights.contains("K"))b.rights|=1;if(rights.contains("Q"))b.rights|=2;
    if(rights.contains("k"))b.rights|=4;if(rights.contains("q"))b.rights|=8;
    b.ep=-1;String ep=f.length>3?f[3]:"-";
    if(ep.matches("[a-h][36]"))b.ep=(8-(ep.charAt(1)-'0'))*8+ep.charAt(0)-'a';
    if(f.length>4)try{b.halfmove=Integer.parseInt(f[4]);}catch(Exception ignored){}
    if(f.length>5)try{b.fullmove=Integer.parseInt(f[5]);}catch(Exception ignored){}
    if(!plausible(b))throw new IllegalArgumentException("Position invalide : vérifie les pièces et les rois");
    return b;
  }
  public static boolean plausible(Board b){
    int wk=0,bk=0,wp=0,bp=0,w=0,k=0;
    for(int i=0;i<64;i++){
      char p=b.b[i];if(p=='.')continue;
      if(p=='K')wk++;if(p=='k')bk++;
      if(white(p))w++;else k++;
      if(p=='P')wp++;if(p=='p')bp++;
      if((i<8||i>=56)&&Character.toLowerCase(p)=='p')return false;
    }
    return wk==1&&bk==1&&w<=16&&k<=16&&wp<=8&&bp<=8;
  }
  public static Board initial(){Board b=new Board();String ranks="rnbqkbnrpppppppp................................PPPPPPPPRNBQKBNR";for(int i=0;i<64;i++)b.b[i]=ranks.charAt(i);return b;}
  public static boolean squareAttacked(Board s,int target, boolean byWhite){
    int tr=row(target),tc=col(target); char[] b=s.b;
    // From a target square, the pawn source is one rank below its attack direction.
    int pr=tr+(byWhite?1:-1);
    if(pr>=0&&pr<8)for(int dc:new int[]{-1,1}){int c=tc+dc;if(c>=0&&c<8&&b[pr*8+c]==(byWhite?'P':'p'))return true;}
    for(int[] d:new int[][]{{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}}){int r=tr+d[0],c=tc+d[1];if(r>=0&&r<8&&c>=0&&c<8&&b[r*8+c]==(byWhite?'N':'n'))return true;}
    for(int dr=-1;dr<=1;dr++)for(int dc=-1;dc<=1;dc++)if(dr!=0||dc!=0){int r=tr+dr,c=tc+dc;if(r>=0&&r<8&&c>=0&&c<8&&b[r*8+c]==(byWhite?'K':'k'))return true;}
    for(int dr=-1;dr<=1;dr++)for(int dc=-1;dc<=1;dc++){
      if(dr==0&&dc==0)continue; boolean diagonal=dr!=0&&dc!=0;int r=tr+dr,c=tc+dc;
      while(r>=0&&r<8&&c>=0&&c<8){char p=b[r*8+c];if(p!='.') {if(pieceFor(p,byWhite)){char z=Character.toLowerCase(p);if(z=='q'||(diagonal&&z=='b')||(!diagonal&&z=='r'))return true;}break;}r+=dr;c+=dc;}
    }
    return false;
  }
  public static boolean inCheck(Board s,boolean w){char k=w?'K':'k';int p=-1;for(int i=0;i<64;i++)if(s.b[i]==k){p=i;break;}return p<0||squareAttacked(s,p,!w);}
  static void add(List<Move> list,int from,int to,char p,boolean ep,boolean castle){
    if(Character.toLowerCase(p)=='p'&&(row(to)==0||row(to)==7))for(char q:new char[]{'q','n','r','b'})list.add(new Move(from,to,q,ep,castle));else list.add(new Move(from,to,'.',ep,castle));
  }
  public static List<Move> pseudo(Board s){
    List<Move> out=new ArrayList<>();char[] b=s.b;boolean w=s.whiteTurn;
    for(int f=0;f<64;f++){
      char p=b[f];if(!pieceFor(p,w))continue; int r=row(f),c=col(f);char t=Character.toLowerCase(p);
      if(t=='p'){
        int nr=r+(w?-1:1);if(nr>=0&&nr<8){int to=nr*8+c;if(b[to]=='.'){add(out,f,to,p,false,false);int nn=r+(w?-2:2);if(r==(w?6:1)&&b[nn*8+c]=='.')add(out,f,nn*8+c,p,false,false);}
          for(int d:new int[]{-1,1}){int cc=c+d;if(cc<0||cc>=8)continue;to=nr*8+cc;if(opp(p,b[to])&&Character.toLowerCase(b[to])!='k')add(out,f,to,p,false,false);else if(s.ep==to&&b[to]=='.'&&b[r*8+cc]==(w?'p':'P'))add(out,f,to,p,true,false);}
        }
      } else if(t=='n'||t=='k'){
        int[][] ds=t=='n'?new int[][]{{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}}:new int[][]{{-1,-1},{-1,0},{-1,1},{0,-1},{0,1},{1,-1},{1,0},{1,1}};
        for(int[] d:ds){int rr=r+d[0],cc=c+d[1];if(rr<0||rr>7||cc<0||cc>7)continue;int to=rr*8+cc;if(!pieceFor(b[to],w)&&Character.toLowerCase(b[to])!='k')add(out,f,to,p,false,false);}
        if(t=='k'&&f==(w?60:4)&&!inCheck(s,w)){
          if((s.rights&(w?CASTLE_WK:CASTLE_BK))!=0&&b[f+3]==(w?'R':'r')&&b[f+1]=='.'&&b[f+2]=='.'&&!squareAttacked(s,f+1,!w)&&!squareAttacked(s,f+2,!w))add(out,f,f+2,p,false,true);
          if((s.rights&(w?CASTLE_WQ:CASTLE_BQ))!=0&&b[f-4]==(w?'R':'r')&&b[f-1]=='.'&&b[f-2]=='.'&&b[f-3]=='.'&&!squareAttacked(s,f-1,!w)&&!squareAttacked(s,f-2,!w))add(out,f,f-2,p,false,true);
        }
      } else {
        for(int dr=-1;dr<=1;dr++)for(int dc=-1;dc<=1;dc++){
          if(dr==0&&dc==0)continue;boolean diag=dr!=0&&dc!=0;if(t=='b'&&!diag||t=='r'&&diag)continue;
          for(int rr=r+dr,cc=c+dc;rr>=0&&rr<8&&cc>=0&&cc<8;rr+=dr,cc+=dc){int to=rr*8+cc;if(pieceFor(b[to],w)||Character.toLowerCase(b[to])=='k')break;add(out,f,to,p,false,false);if(b[to]!='.')break;}
        }
      }
    }
    return out;
  }
  public static Board move(Board s,Move m){
    Board n=s.copy();char p=n.b[m.from],captured=n.b[m.to];n.b[m.from]='.';n.b[m.to]=m.promotion=='.'?p:(s.whiteTurn?Character.toUpperCase(m.promotion):Character.toLowerCase(m.promotion));
    if(m.ep)n.b[m.to+(s.whiteTurn?8:-8)]='.';
    if(m.castle){if(m.to>m.from){n.b[m.from+1]=n.b[m.from+3];n.b[m.from+3]='.';}else{n.b[m.from-1]=n.b[m.from-4];n.b[m.from-4]='.';}}
    if(p=='K')n.rights&=~3;if(p=='k')n.rights&=~12;
    if(m.from==63||m.to==63)n.rights&=~1;if(m.from==56||m.to==56)n.rights&=~2;
    if(m.from==7||m.to==7)n.rights&=~4;if(m.from==0||m.to==0)n.rights&=~8;
    n.ep=Character.toLowerCase(p)=='p'&&Math.abs(m.to-m.from)==16?(m.from+m.to)/2:-1;
    n.halfmove=(Character.toLowerCase(p)=='p'||captured!='.'||m.ep)?0:n.halfmove+1;
    if(!s.whiteTurn)n.fullmove++;n.whiteTurn=!s.whiteTurn;return n;
  }
  public static List<Move> legal(Board b){List<Move> moves=new ArrayList<>();for(Move m:pseudo(b))if(!inCheck(move(b,m),b.whiteTurn))moves.add(m);return moves;}
  public static int pieceValue(char p){switch(Character.toLowerCase(p)){case 'p':return 100;case 'n':return 320;case 'b':return 330;case 'r':return 500;case 'q':return 900;case 'k':return 20000;default:return 0;}}
  public static int evaluate(Board b){
    int score=0;for(int i=0;i<64;i++){char p=b.b[i];if(p=='.')continue;int val=pieceValue(p);int r=row(i),c=col(i),center=3-Math.max(Math.abs(3-r),Math.abs(3-c));int bonus=0;switch(Character.toLowerCase(p)){
      case 'p':bonus=(white(p)?6-r:r-1)*6+center*3;break;
      case 'n':bonus=center*10;break;
      case 'b':bonus=center*6;break;
      case 'q':bonus=center*2;break;
      default:break;
    }score+=(white(p)?1:-1)*(val+bonus);}
    return b.whiteTurn?score:-score;
  }
  public static int moveOrder(Board b,Move m){char taken=b.b[m.to];int score=pieceValue(taken)*12-pieceValue(b.b[m.from]);if(m.promotion!='.')score+=8000;if(m.ep)score+=1200;if(m.castle)score+=200;return score;}
  static List<Move> sorted(Board b){List<Move> l=legal(b);Collections.sort(l,(a,c)->Integer.compare(moveOrder(b,c),moveOrder(b,a)));return l;}
}
