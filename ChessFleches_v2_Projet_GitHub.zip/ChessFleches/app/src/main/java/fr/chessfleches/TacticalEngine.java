package fr.chessfleches;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Analyse locale légère, moins forte que Stockfish. Les styles changent le classement des coups. */
public class TacticalEngine {
  private long deadline, nodes;
  public static final class Suggestion {
    public final Chess.Move move;
    public final int score;
    public final StyleMode style;
    public Suggestion(Chess.Move m,int s,StyleMode mode){move=m;score=s;style=mode;}
  }
  private static final class Eval {Chess.Move move; Chess.Board after;int base;Eval(Chess.Move m,Chess.Board a,int b){move=m;after=a;base=b;}}
  private static class OutOfTime extends RuntimeException{}
  private void checkTime(){if((++nodes&255)==0 && System.nanoTime()>deadline)throw new OutOfTime();}
  public List<Suggestion> analyze(Chess.Board b, List<StyleMode> styles, int arrows, int timeMs, int maxDepth){
    List<Chess.Move> roots=Chess.sorted(b);
    List<Suggestion> out=new ArrayList<>();if(roots.isEmpty()||styles==null||styles.isEmpty())return out;
    deadline=System.nanoTime()+Math.max(200,timeMs)*1_000_000L;nodes=0;
    List<Eval> best=new ArrayList<>();for(Chess.Move m:roots)best.add(new Eval(m,Chess.move(b,m),-Chess.evaluate(Chess.move(b,m))));
    for(int depth=1;depth<=Math.max(1,Math.min(5,maxDepth));depth++){
      List<Eval> stage=new ArrayList<>();boolean complete=true;
      for(Chess.Move m:roots){
        if(System.nanoTime()>deadline){complete=false;break;}
        Chess.Board after=Chess.move(b,m);int score;
        try{score=-search(after,depth-1,-50000,50000,1);}catch(OutOfTime ex){complete=false;break;}
        stage.add(new Eval(m,after,score));
      }
      if(!complete||stage.size()!=roots.size())break;
      stage.sort((x,y)->Integer.compare(y.base,x.base));best=stage;
      roots=new ArrayList<>();for(Eval e:stage)roots.add(e.move);
    }
    int bestBase=-50000;for(Eval e:best)bestBase=Math.max(bestBase,e.base);
    final int strongest=bestBase;
    Set<String> used=new HashSet<>();int n=Math.min(5,Math.max(1,arrows));
    // Un meilleur coup de chaque style activé, puis les autres propositions.
    for(int pass=0;pass<Math.max(n,styles.size())&&out.size()<n;pass++){
      for(StyleMode style:styles){
        if(out.size()>=n)break;
        List<Eval> ranked=new ArrayList<>(best);
        ranked.sort((x,y)->Integer.compare(styleScore(b,y,style,strongest),styleScore(b,x,style,strongest)));
        int rank=0;
        for(Eval e:ranked){
          if(used.contains(Chess.uci(e.move)))continue;
          if(rank++<pass)continue;
          used.add(Chess.uci(e.move));out.add(new Suggestion(e.move,styleScore(b,e,style,strongest),style));break;
        }
      }
    }
    return out;
  }
  private int styleScore(Chess.Board b,Eval e,StyleMode st,int best){
    Chess.Move m=e.move;Chess.Board after=e.after;
    int score=e.base;boolean check=Chess.inCheck(after,after.whiteTurn);
    char mover=b.b[m.from];char target=b.b[m.to];
    int captured=Chess.pieceValue(target),piece=Chess.pieceValue(mover);
    int center=6-(Math.abs(3-Chess.row(m.to))+Math.abs(3-Chess.col(m.to)));
    int threats=0,checks=0;
    // Mesure des attaques sur les pièces ennemies et du danger sur notre pièce.
    int attackedVal=0;
    for(int i=0;i<64;i++){
      char victim=after.b[i];if(victim=='.'||!Chess.pieceFor(victim,after.whiteTurn))continue;
      if(Chess.squareAttacked(after,i,!after.whiteTurn))threats++;
      if(Chess.squareAttacked(after,i,!after.whiteTurn)&&Chess.pieceValue(victim)>=500)attackedVal++;
    }
    boolean moverThreatened=Chess.squareAttacked(after,m.to,after.whiteTurn);
    int movedSafety=moverThreatened?Math.min(70,piece/8):0;
    switch(st){
      case FOU:
        // Fou : variantes tranchantes, échecs, gambits et sacrifices raisonnables.
        score+=check?90:0;score+=Math.min(50,captured/15)+center*4+Math.min(35,threats*9)+attackedVal*18;
        if(moverThreatened&&piece>=300&&e.base>=best-100)score+=26;
        if(moverThreatened&&e.base<best-155)score-=120;
        break;
      case DEFENSIF:
        score-=movedSafety*2;score+=(m.castle?70:0)+Math.min(25,captured/40);
        if(Chess.inCheck(b,b.whiteTurn))score+=25;
        score-=threats*8;break;
      case ATTAQUE:
        score+=(check?72:0)+Math.min(42,captured/18)+center*7+Math.min(45,threats*10);
        score-=movedSafety/3;break;
      case HUMAIN:
        score+=center*4+(m.castle?45:0)+Math.min(12,captured/35)-movedSafety*2;
        if(Character.toLowerCase(mover)=='n'||Character.toLowerCase(mover)=='b')score+=12;
        if(e.base<best-75)score-=90;break;
      case PIEGES:
        score+=(check?60:0)+Math.min(85,threats*15)+attackedVal*27+center*4;
        if(moverThreatened&&piece<=330&&e.base>=best-80)score+=15;
        if(e.base<best-140)score-=100;break;
    }
    return score;
  }
  private int search(Chess.Board b,int depth,int alpha,int beta,int ply){
    checkTime();List<Chess.Move> moves=Chess.sorted(b);
    if(moves.isEmpty())return Chess.inCheck(b,b.whiteTurn)?-29000+ply:0;
    if(depth<=0)return quiet(b,alpha,beta,0,ply);
    int best=-50000;
    for(Chess.Move m:moves){int s=-search(Chess.move(b,m),depth-1,-beta,-alpha,ply+1);if(s>best)best=s;if(s>alpha)alpha=s;if(alpha>=beta)break;}
    return best;
  }
  private int quiet(Chess.Board b,int alpha,int beta,int qdepth,int ply){
    checkTime();int stand=Chess.evaluate(b);boolean check=Chess.inCheck(b,b.whiteTurn);
    if(!check){if(stand>=beta)return beta;if(stand>alpha)alpha=stand;}
    if(qdepth>=4)return stand;
    List<Chess.Move> moves=Chess.sorted(b);if(moves.isEmpty())return check?-29000+ply:0;
    for(Chess.Move m:moves){if(!check&&b.b[m.to]=='.'&&!m.ep&&m.promotion=='.')continue;
      int v=-quiet(Chess.move(b,m),-beta,-alpha,qdepth+1,ply+1);
      if(v>=beta)return beta;if(v>alpha)alpha=v;}
    return alpha;
  }
}
