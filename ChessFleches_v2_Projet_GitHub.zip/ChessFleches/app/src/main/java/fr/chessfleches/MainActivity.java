package fr.chessfleches;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import java.util.EnumMap;

/** Réglages accessibles depuis la bulle flottante en cours de partie. */
public class MainActivity extends Activity {
  private static final int CAPTURE_REQUEST=1001;
  private TextView info,countLabel,effortLabel;
  private RadioGroup colors,turn;
  private SeekBar countSeek,effortSeek;
  private EnumMap<StyleMode,CheckBox> checks=new EnumMap<>(StyleMode.class);
  private EditText fen;
  private SharedPreferences prefs;
  private int px(int d){return (int)(getResources().getDisplayMetrics().density*d+.5f);}
  private TextView label(String text,int sp){TextView t=new TextView(this);t.setText(text);t.setTextSize(sp);t.setTextColor(Color.WHITE);t.setPadding(0,px(8),0,px(8));return t;}
  private Button action(String text,LinearLayout root){Button b=new Button(this);b.setText(text);b.setAllCaps(false);root.addView(b,new LinearLayout.LayoutParams(-1,px(53)));return b;}
  @Override public void onCreate(Bundle state){super.onCreate(state);prefs=getSharedPreferences("settings",MODE_PRIVATE);
    ScrollView sv=new ScrollView(this);LinearLayout root=new LinearLayout(this);
    root.setOrientation(1);root.setPadding(px(19),px(20),px(19),px(25));root.setBackgroundColor(0xFF101923);
    sv.addView(root);setContentView(sv);
    TextView title=label("♟  CHESS FLÈCHES · RÉGLAGES",22);title.setTextColor(0xFF8EF0AA);root.addView(title);
    root.addView(label("Version 0.2 · positions déjà commencées (expérimental)",13));
    root.addView(label("Nombre de flèches",18));countLabel=label("",15);root.addView(countLabel);
    countSeek=new SeekBar(this);countSeek.setMax(4);countSeek.setProgress(prefs.getInt("count",3)-1);
    countLabel.setText((countSeek.getProgress()+1)+" flèche(s)");root.addView(countSeek);
    countSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      public void onProgressChanged(SeekBar b,int v,boolean fromUser){countLabel.setText((v+1)+" flèche(s)");}
      public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}
    });
    root.addView(label("Force d'analyse (moteur local)",18));effortLabel=label("",15);root.addView(effortLabel);
    effortSeek=new SeekBar(this);effortSeek.setMax(4);effortSeek.setProgress(prefs.getInt("effort",3)-1);
    effortLabel.setText("Niveau "+(effortSeek.getProgress()+1)+" / 5 — plus haut = plus lent");root.addView(effortSeek);
    effortSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      public void onProgressChanged(SeekBar b,int v,boolean fromUser){effortLabel.setText("Niveau "+(v+1)+" / 5 — plus haut = plus lent");}
      public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}
    });
    root.addView(label("Couleur des flèches = style de jeu",18));
    root.addView(label("Active les styles voulus. Le moteur propose des coups différents selon les critères ; une couleur correspond toujours au même style.",13));
    for(StyleMode style:StyleMode.values()){
      CheckBox cb=new CheckBox(this);cb.setText("●  "+style.label);cb.setTextColor(style.color);
      cb.setTextSize(17);cb.setPadding(0,px(5),0,px(5));
      cb.setChecked(prefs.getBoolean("style_"+style.name(),style==StyleMode.FOU||style==StyleMode.ATTAQUE||style==StyleMode.PIEGES));
      checks.put(style,cb);root.addView(cb);
    }
    root.addView(label("Fou : privilégie les échecs, gambits, sacrifices et attaques calculées. Inspiré de l'idée du mode Fou, sans utiliser ni reproduire le moteur de Chess & Checkers.",13));
    root.addView(label("Ma couleur (celle en bas de l'échiquier)",18));
    colors=new RadioGroup(this);colors.setOrientation(0);
    RadioButton w=new RadioButton(this);w.setText("Blancs");w.setTextColor(Color.WHITE);w.setId(101);colors.addView(w);
    RadioButton b=new RadioButton(this);b.setText("Noirs");b.setTextColor(Color.WHITE);b.setId(102);colors.addView(b);
    root.addView(colors);colors.check(prefs.getBoolean("white",true)?101:102);
    root.addView(label("Qui doit jouer au moment du premier scan ?",18));
    turn=new RadioGroup(this);turn.setOrientation(0);
    RadioButton mine=new RadioButton(this);mine.setId(201);mine.setText("Moi");mine.setTextColor(Color.WHITE);turn.addView(mine);
    RadioButton other=new RadioButton(this);other.setId(202);other.setText("L'adversaire");other.setTextColor(Color.WHITE);turn.addView(other);
    root.addView(turn);turn.check(prefs.getBoolean("myTurnFirst",true)?201:202);
    root.addView(label("Position manuelle (facultatif)",17));
    root.addView(label("Le scan essaie de reconnaître une partie commencée. Si le thème n'est pas reconnu, tu peux entrer un code FEN ici. Laisse vide pour le scan automatique.",13));
    fen=new EditText(this);fen.setSingleLine(false);fen.setMinLines(2);fen.setTextColor(Color.WHITE);
    fen.setHintTextColor(0xFF8593A4);fen.setHint("Ex. rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
    fen.setText(prefs.getString("fen",""));root.addView(fen);
    Button save=action("✓ ENREGISTRER ET RETOURNER AU JEU",root);save.setOnClickListener(v->{if(saveSettings()){
      startService(new Intent(this,CaptureService.class).setAction(CaptureService.UPDATE));moveTaskToBack(true);
    }});
    Button overlay=action("Autoriser la bulle au-dessus des applis",root);
    overlay.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))));
    Button start=action("▶ DÉMARRER LA CAPTURE",root);start.setOnClickListener(v->startCapture());
    Button stop=action("■ ARRÊTER LA CAPTURE",root);stop.setOnClickListener(v->startService(new Intent(this,CaptureService.class).setAction(CaptureService.STOP)));
    info=label("Les captures sont analysées sur ton téléphone, sans serveur externe.",13);root.addView(info);
    root.addView(label("Moteur intégré ≠ Stockfish. Détection de positions expérimentale : s'il y a un doute, aucune flèche ne doit s'afficher. Utilise-le pour l'entraînement contre l'ordinateur.",13));
  }
  private boolean saveSettings(){
    boolean selected=false;for(StyleMode style:StyleMode.values())if(checks.get(style).isChecked())selected=true;
    if(!selected){new AlertDialog.Builder(this).setMessage("Sélectionne au moins un style de jeu.").setPositiveButton("OK",null).show();return false;}
    String custom=fen.getText().toString().trim();
    if(!custom.isEmpty())try{Chess.fromFen(custom);}catch(IllegalArgumentException ex){
      new AlertDialog.Builder(this).setTitle("Position FEN invalide").setMessage(ex.getMessage()).setPositiveButton("OK",null).show();return false;
    }
    SharedPreferences.Editor e=prefs.edit().putBoolean("white",colors.getCheckedRadioButtonId()!=102)
       .putBoolean("myTurnFirst",turn.getCheckedRadioButtonId()!=202)
       .putInt("count",countSeek.getProgress()+1).putInt("effort",effortSeek.getProgress()+1).putString("fen",custom);
    for(StyleMode style:StyleMode.values())e.putBoolean("style_"+style.name(),checks.get(style).isChecked());
    e.apply();return true;
  }
  private void startCapture(){
    if(!saveSettings())return;
    if(!Settings.canDrawOverlays(this)){
      new AlertDialog.Builder(this).setTitle("Autorisation nécessaire")
        .setMessage("Autorise l'affichage de la bulle au-dessus des autres applications.")
        .setPositiveButton("Ouvrir",(d,w)->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))))
        .setNegativeButton("Annuler",null).show();return;
    }
    MediaProjectionManager mgr=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
    startActivityForResult(mgr.createScreenCaptureIntent(),CAPTURE_REQUEST);
  }
  @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);
    if(req==CAPTURE_REQUEST&&result==RESULT_OK&&data!=null){
      Intent service=new Intent(this,CaptureService.class).setAction(CaptureService.START);
      service.putExtra("resultCode",result);service.putExtra("resultData",data);
      if(Build.VERSION.SDK_INT>=26)startForegroundService(service);else startService(service);
      info.setText("Capture autorisée. Ouvre Chess Universe sur ta partie, même déjà commencée.");
      new Handler().postDelayed(()->moveTaskToBack(true),800);
    }else if(req==CAPTURE_REQUEST)info.setText("Capture refusée.");
  }
}
