package fr.chessfleches;

/** Modes de recherche originaux, sans copier le moteur d'une autre application. */
public enum StyleMode {
  FOU("Fou · sacrifices / gambits", 0xFFE879F9),
  DEFENSIF("Défensif · solidité", 0xFF55B9FF),
  ATTAQUE("Attaque · pression", 0xFFFF646C),
  HUMAIN("Humain · coups naturels", 0xFF25D5BF),
  PIEGES("Pièges · menaces", 0xFFFFB443);

  public final String label;
  public final int color;
  StyleMode(String text, int argb){label=text;color=argb;}
  public String shortName(){return name().equals("PIEGES")?"PIÈGES":name().equals("DEFENSIF")?"DÉFENSIF":name();}
}
