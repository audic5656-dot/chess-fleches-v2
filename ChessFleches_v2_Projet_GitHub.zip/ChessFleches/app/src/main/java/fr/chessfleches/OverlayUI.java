package fr.chessfleches;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class OverlayUI {
  private final Service ctx;
  private final WindowManager wm;
  private final Handler main=new Handler(Looper.getMainLooper());
  private final ArrowLayer layer;
  private final LinearLayout bubble;
  private final TextView status;
  private final Button color;
  private final WindowManager.LayoutParams bubbleParams;
  private int dp(float v){return (int)(ctx.getResources().getDisplayMetrics().density*v+.5f);}
  private Button button(String text,LinearLayout parent){
    Button b=new Button(ctx);b.setText(text);b.setAllCaps(false);b.setTextSize(11);b.setMinWidth(0);
    b.setMinimumWidth(0);b.setPadding(dp(2),0,dp(2),0);parent.addView(b);
    return b;
  }
  OverlayUI(Service service,boolean playingWhite){
    ctx=service;wm=(WindowManager)ctx.getSystemService(Service.WINDOW_SERVICE);
    layer=new ArrowLayer(ctx);WindowManager.LayoutParams ap=new WindowManager.LayoutParams(-1,-1,
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|
      WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
    ap.gravity=Gravity.TOP|Gravity.LEFT;wm.addView(layer,ap);
    bubble=new LinearLayout(ctx);bubble.setOrientation(1);bubble.setPadding(dp(9),dp(5),dp(9),dp(4));
    bubble.setBackgroundColor(0xED10202E);
    TextView header=new TextView(ctx);header.setText("♟ CHESS FLÈCHES  ⋮⋮");
    header.setTextColor(0xFF9FEFAE);header.setTextSize(13);
    header.setPadding(dp(3),dp(4),dp(3),dp(4));bubble.addView(header);
    status=new TextView(ctx);status.setText("Détection de la position…");status.setTextColor(Color.WHITE);
    status.setTextSize(12);status.setPadding(dp(3),0,dp(3),dp(4));bubble.addView(status);
    LinearLayout toolbar=new LinearLayout(ctx);toolbar.setOrientation(0);bubble.addView(toolbar);
    color=button(playingWhite?"Blancs":"Noirs",toolbar);
    color.setOnClickListener(v->ctx.startService(new Intent(ctx,CaptureService.class).setAction(CaptureService.SWITCH)));
    button("↻",toolbar).setOnClickListener(v->ctx.startService(new Intent(ctx,CaptureService.class).setAction(CaptureService.RESCAN)));
    button("⚙",toolbar).setOnClickListener(v->{Intent i=new Intent(ctx,MainActivity.class);
       i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);ctx.startActivity(i);});
    button("✕",toolbar).setOnClickListener(v->ctx.startService(new Intent(ctx,CaptureService.class).setAction(CaptureService.STOP)));
    bubbleParams=new WindowManager.LayoutParams(dp(245),WindowManager.LayoutParams.WRAP_CONTENT,
       WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
       WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
    bubbleParams.gravity=Gravity.TOP|Gravity.LEFT;bubbleParams.x=dp(8);bubbleParams.y=dp(54);
    wm.addView(bubble,bubbleParams);
    header.setOnTouchListener(new View.OnTouchListener(){int x,y;float touchX,touchY;
      @Override public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){
        case MotionEvent.ACTION_DOWN:x=bubbleParams.x;y=bubbleParams.y;touchX=e.getRawX();touchY=e.getRawY();return true;
        case MotionEvent.ACTION_MOVE:bubbleParams.x=x+(int)(e.getRawX()-touchX);bubbleParams.y=y+(int)(e.getRawY()-touchY);
          try{wm.updateViewLayout(bubble,bubbleParams);}catch(Exception ignored){}return true;
        default:return true;
      }}
    });
  }
  public void status(String text){main.post(()->status.setText(text));}
  public void setColor(boolean white){main.post(()->color.setText(white?"Blancs":"Noirs"));}
  public void show(BoardVision.Box rect,List<TacticalEngine.Suggestion> suggestions,boolean whiteBottom){
    List<TacticalEngine.Suggestion> copy=suggestions==null?new ArrayList<>():new ArrayList<>(suggestions);
    main.post(()->{layer.board=rect;layer.suggestions=copy;layer.whiteBottom=whiteBottom;layer.invalidate();});
  }
  public void hideForSampling(boolean hide){main.post(()->layer.setVisibility(hide?View.INVISIBLE:View.VISIBLE));}
  public void close(){main.post(()->{
    try{wm.removeViewImmediate(layer);}catch(Exception ignored){}
    try{wm.removeViewImmediate(bubble);}catch(Exception ignored){}
  });}
  private class ArrowLayer extends View {
    BoardVision.Box board;List<TacticalEngine.Suggestion> suggestions=new ArrayList<>();boolean whiteBottom=true;
    Paint p=new Paint(3);
    ArrowLayer(Service service){super(service);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    @Override protected void onDraw(Canvas canvas){
      super.onDraw(canvas);if(board==null)return;
      int n=Math.min(5,suggestions.size());float sz=board.size/8f;
      for(int i=n-1;i>=0;i--){
        TacticalEngine.Suggestion item=suggestions.get(i);Chess.Move move=item.move;
        int fromR=Chess.row(move.from),fromC=Chess.col(move.from);
        int toR=Chess.row(move.to),toC=Chess.col(move.to);
        if(!whiteBottom){fromR=7-fromR;fromC=7-fromC;toR=7-toR;toC=7-toC;}
        float x=board.x+(fromC+.5f)*sz,y=board.y+(fromR+.5f)*sz;
        float tx=board.x+(toC+.5f)*sz,ty=board.y+(toR+.5f)*sz;
        float dx=tx-x,dy=ty-y,len=(float)Math.hypot(dx,dy);if(len<1)continue;
        float ux=dx/len,uy=dy/len,cut=sz*.16f,endX=tx-ux*cut,endY=ty-uy*cut;
        float thickness=Math.max(4,sz*(i==0?.13f:.085f));
        p.setColor(item.style.color);p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(thickness);
        canvas.drawLine(x,y,endX-ux*sz*.24f,endY-uy*sz*.24f,p);
        p.setStyle(Paint.Style.FILL);Path head=new Path();head.moveTo(endX,endY);
        head.lineTo(endX-ux*sz*.45f-uy*sz*.24f,endY-uy*sz*.45f+ux*sz*.24f);
        head.lineTo(endX-ux*sz*.45f+uy*sz*.24f,endY-uy*sz*.45f-ux*sz*.24f);
        head.close();canvas.drawPath(head,p);
        p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);p.setTextSize(sz*.22f);
        canvas.drawText(Integer.toString(i+1),x+sz*.15f,y-sz*.16f,p);
      }
      p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.5f);p.setColor(0xAA6CEB9C);
      canvas.drawRect(new RectF(board.x,board.y,board.x+board.size,board.y+board.size),p);
    }
  }
}
