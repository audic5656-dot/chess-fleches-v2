package fr.chessfleches;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/** Projection locale d'écran. Aucune image n'est transmise sur Internet. */
public class CaptureService extends Service {
  public static final String START="fr.chessfleches.START",STOP="fr.chessfleches.STOP",
      RESCAN="fr.chessfleches.RESCAN",SWITCH="fr.chessfleches.SWITCH",UPDATE="fr.chessfleches.UPDATE";
  private MediaProjection projection;private VirtualDisplay display;private ImageReader reader;
  private OverlayUI overlay;private HandlerThread thread;private Handler worker;
  private volatile boolean running=false;
  private boolean white=true, myTurnFirst=true;
  private BoardVision vision;private Chess.Board game;private TacticalEngine engine;
  private String pending="",scanPending="",analyzed="";private int same=0,scanSame=0,frames=0;
  private List<TacticalEngine.Suggestion> arrows=new ArrayList<>();
  private int width,height,count=3,effort=3;private List<StyleMode> styles=new ArrayList<>();
  private String customFen="";
  @Override public IBinder onBind(Intent intent){return null;}
  @Override public void onCreate(){super.onCreate();vision=new BoardVision(this);engine=new TacticalEngine();game=Chess.initial();loadSettings();}
  private void loadSettings(){
    SharedPreferences p=getSharedPreferences("settings",MODE_PRIVATE);
    white=p.getBoolean("white",true);myTurnFirst=p.getBoolean("myTurnFirst",true);
    count=Math.max(1,Math.min(5,p.getInt("count",3)));
    effort=Math.max(1,Math.min(5,p.getInt("effort",3)));
    styles.clear();for(StyleMode s:StyleMode.values())if(p.getBoolean("style_"+s.name(),s==StyleMode.FOU||s==StyleMode.ATTAQUE||s==StyleMode.PIEGES))styles.add(s);
    if(styles.isEmpty())styles.add(StyleMode.FOU);
    customFen=p.getString("fen","").trim();
  }
  @Override public int onStartCommand(Intent intent,int flags,int startId){
    if(intent==null)return START_NOT_STICKY;
    String action=intent.getAction();
    if(STOP.equals(action)){stopSelf();return START_NOT_STICKY;}
    if(RESCAN.equals(action)){resetSession();return START_NOT_STICKY;}
    if(SWITCH.equals(action)){
      white=!white;getSharedPreferences("settings",MODE_PRIVATE).edit().putBoolean("white",white).apply();
      if(overlay!=null)overlay.setColor(white);resetSession();return START_NOT_STICKY;
    }
    if(UPDATE.equals(action)){
      boolean oldWhite=white,oldTurn=myTurnFirst;String oldFen=customFen;
      loadSettings();analyzed="";arrows.clear();
      if(overlay!=null)overlay.setColor(white);
      if(oldWhite!=white||oldTurn!=myTurnFirst||!oldFen.equals(customFen))resetSession();
      else if(overlay!=null)overlay.status("Réglages mis à jour ✓");
      return START_NOT_STICKY;
    }
    if(START.equals(action))start(intent);
    return START_NOT_STICKY;
  }
  private void resetSession(){
    vision.reset();game=null;pending="";scanPending="";scanSame=0;same=0;frames=0;analyzed="";arrows.clear();
    if(overlay!=null){overlay.show(null,arrows,white);overlay.status("Scan de la position en cours…");}
  }
  private Notification notification(){
    NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel("chess","Chess Flèches — capture",NotificationManager.IMPORTANCE_LOW));
    return new Notification.Builder(this,"chess").setContentTitle("Chess Flèches actif")
      .setContentText("Analyse locale · Ouvre Chess Universe")
      .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build();
  }
  private void start(Intent intent){
    if(running){if(overlay!=null)overlay.status("Capture déjà active");return;}
    loadSettings();resetSession();
    try{
      if(Build.VERSION.SDK_INT>=29)startForeground(22,notification(),android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
      else startForeground(22,notification());
      running=true;WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);DisplayMetrics dm=new DisplayMetrics();
      wm.getDefaultDisplay().getRealMetrics(dm);width=dm.widthPixels;height=dm.heightPixels;
      overlay=new OverlayUI(this,white);
      thread=new HandlerThread("chess-vision");thread.start();worker=new Handler(thread.getLooper());
      MediaProjectionManager mgr=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
      Intent token=Build.VERSION.SDK_INT>=33?intent.getParcelableExtra("resultData",Intent.class):
        (Intent)intent.getParcelableExtra("resultData");
      projection=mgr.getMediaProjection(intent.getIntExtra("resultCode",-1),token);
      if(projection==null)throw new IllegalStateException("Autorisation de capture absente");
      projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){stopSelf();}},new Handler(getMainLooper()));
      reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,2);
      display=projection.createVirtualDisplay("ChessFleches",width,height,dm.densityDpi,
         DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,worker);
      overlay.status("Ouvre une position, même déjà commencée");
      worker.postDelayed(this::sample,900);
    }catch(Exception e){if(overlay!=null)overlay.status("Erreur capture : "+e.getMessage());stopSelf();}
  }
  private void sample(){
    if(!running)return;
    if(overlay!=null)overlay.hideForSampling(true);
    worker.postDelayed(()->{
      Image image=null;Bitmap bmp=null;
      try{
        if(reader!=null)image=reader.acquireLatestImage();
        if(image!=null){bmp=toBitmap(image);process(bmp);}
      }catch(Exception e){if(overlay!=null)overlay.status("Erreur de lecture : "+e.getClass().getSimpleName());}
      finally{
        if(image!=null)image.close();if(bmp!=null)bmp.recycle();
        if(overlay!=null)overlay.hideForSampling(false);
      }
      if(running)worker.postDelayed(this::sample,950);
    },160);
  }
  private Bitmap toBitmap(Image image){
    Image.Plane plane=image.getPlanes()[0];ByteBuffer buf=plane.getBuffer();int stride=plane.getRowStride(),pixel=plane.getPixelStride();
    Bitmap padded=Bitmap.createBitmap(stride/pixel,height,Bitmap.Config.ARGB_8888);
    buf.rewind();padded.copyPixelsFromBuffer(buf);
    Bitmap actual=Bitmap.createBitmap(padded,0,0,width,height);padded.recycle();return actual;
  }
  private void process(Bitmap image){
    if(!vision.calibrated()){
      if(++frames%2!=0)return;
      BoardVision.Box rect=vision.detectOnScreen(image);
      if(rect==null){overlay.show(null,new ArrayList<>(),white);overlay.status("Échiquier introuvable · ouvre la position");return;}
      Chess.Board scanned=null;
      if(!customFen.isEmpty()){
        try{scanned=Chess.fromFen(customFen);}catch(IllegalArgumentException ex){overlay.status("FEN invalide dans les réglages");return;}
      }else scanned=vision.scanPosition(image,rect,white,myTurnFirst==white);
      if(scanned==null){scanSame=0;overlay.show(null,new ArrayList<>(),white);overlay.status("Reconnaissance incertaine · ↻ pour rescanner");return;}
      String fen=scanned.fen();
      if(fen.equals(scanPending))scanSame++;else{scanPending=fen;scanSame=1;}
      if(scanSame<2){overlay.status("Vérification de la position…");return;}
      game=scanned;vision.calibrate(image,rect,game,white);
      overlay.status("Position reconnue ✓ · "+(game.whiteTurn?"Blancs":"Noirs")+" au trait");
      analyzed="";pending="";same=0;
    }else{
      Chess.Move next=vision.detectMove(image,game,white);
      if(next==null){pending="";same=0;}
      else if(Chess.uci(next).equals(pending)){
        if(++same>=2){game=Chess.move(game,next);same=0;pending="";analyzed="";}
      }else{pending=Chess.uci(next);same=1;}
    }
    if(game==null)return;
    if(game.whiteTurn!=white){overlay.show(vision.board(),new ArrayList<>(),white);overlay.status("Tour adverse · suivi actif");return;}
    String fen=game.fen();
    if(!fen.equals(analyzed)){
      List<TacticalEngine.Suggestion> top=engine.analyze(game,styles,count,effort*480,effort);
      arrows=new ArrayList<>(top);analyzed=fen;
    }
    overlay.show(vision.board(),arrows,white);
    if(arrows.isEmpty())overlay.status("Aucun coup légal trouvé");
    else overlay.status("À toi · "+Chess.uci(arrows.get(0).move)+" · "+arrows.get(0).style.shortName());
  }
  @Override public void onDestroy(){
    running=false;if(worker!=null)worker.removeCallbacksAndMessages(null);
    try{if(display!=null)display.release();}catch(Exception ignored){}
    try{if(reader!=null)reader.close();}catch(Exception ignored){}
    try{if(projection!=null)projection.stop();}catch(Exception ignored){}
    if(thread!=null)thread.quitSafely();if(overlay!=null)overlay.close();super.onDestroy();
  }
}
